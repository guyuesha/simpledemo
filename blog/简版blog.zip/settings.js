module.exports = {
  cookieSecret: 'myblog',
  db: 'blog',
  host: 'localhost',
  port: 27017
};
