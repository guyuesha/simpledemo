
/**
 * 转换方法
 * @param  {number} baz index of the inputlist
 * @param  {string} qux name of the inputlist
 * @return {string}     return the reverted value
 */
function foobar(baz,qux){
    /**
     * 声明变量
     */
    var test="test note";
}

/**
 * [foobar description]
 * @param  {[type]} index [description]
 * @param  {[type]} value [description]
 * @return {[type]}       [description]
 */
function foobar(index,value){
    /**
     * define a temp init number
     * @type {Number}
     */
    var foo=1;
    /**
     * [getnum description]
     * @type {String}     */
    var getnum="";
    /**
     * [test description]
     * @type {BNumber}
     */
    var test=2;
    /**
     * [bar dePPscription]
     * DJS
     *
     *
     *
 @type {String}
     */
    var bar="test";
    /**
     * [lele description]
     * @type {Number}
     */
    var lele=2;
}
